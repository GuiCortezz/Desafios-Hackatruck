//
//  Aula6App.swift
//  Aula6
//
//  Created by Turma02-10 on 14/07/25.
//

import SwiftUI

@main
struct Aula6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
