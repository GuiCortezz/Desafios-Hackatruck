//
//  Aula_6.swift
//  Aula6
//
//  Created by Turma02-10 on 14/07/25.
//

import SwiftUI

struct Aula_6: View {
    
    @StateObject var viewModell = ViewModell()
    @State var sheetVieww = false
    @State var aux: HaPo
    
    var body: some View {
   
        
            ZStack {
                Color.red
                    .ignoresSafeArea()
                VStack {
                    Rectangle()
                        .frame(width: 393, height: 200)
                        .foregroundStyle(Color.secondary)
                        .ignoresSafeArea()
                        .overlay(
                            Text("Clique no + para mais informacões!")
                                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                .bold()
                                .multilineTextAlignment(.center)
                        )
                    
                    
                    
                    ScrollView {
                    ForEach(viewModell.personagens){ e in
                        VStack {
                            HStack {
                                AsyncImage(url: URL(string: e.image!)) { image in
                                    
                                    image.resizable()
                                    
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(width: 100, height: 100)
                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                
                                Text(e.name!)
                                    .font(.title)
                                Spacer()
                                
                                Image(systemName:  "plus.app.fill" )
                                    .imageScale(.large)
                                    .onTapGesture {
                                        sheetVieww = true
                                        aux = e
                                    }
                            }
                            .padding()
                            Spacer()
                            
                            }.sheet(isPresented: $sheetVieww) {
                            Tela2(recebe: $aux)
                        }
                    }
                    
                }
            }
        }
        .onAppear(){
            viewModell.fetch()
        }
    }
        
}

#Preview {
    Aula_6(aux: HaPo(id: "", name: "", alternate_names: ["", ""], species: "", gender: "", house: "", dateOfBirth: "", yearOfBirth: 2020, wizard: true, ancestry: "", eyeColour: "", hairColour: "", wand: Wand(wood: "", core: "", lenght: 10.2), patronus: "", hogwartsStudent: true, hogwartsStaff: true, actor: "", alternate_actors: [""], alive: true, image: ""))
}
