import SwiftUI

enum AppFlow {
    case start
    case contratante
    case prestador
}

struct ContentView: View {
    
    @State private var flow: AppFlow = .start

    var body: some View {
        
        switch flow {
            case .start:
                InitialView(flow: $flow)
            case .contratante:
            TabViewContratante(flow: $flow)
            case .prestador:
            CadastroPrestador(flow: $flow)
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(SearchViewModel())
}
