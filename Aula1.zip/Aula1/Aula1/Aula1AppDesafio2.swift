//
//  Aula1AppDesafio2.swift
//  Aula1
//
//  Created by Turma02-10 on 02/07/25.
//

import SwiftUI

struct Aula1AppDesafio2: View {
    var body: some View {
        VStack {
            HStack {
                Image("WhatsApp Image 2020-03-02 at 14.41.09")
                    .resizable()
                    .scaledToFit()
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .padding()
                
                VStack(spacing: 10) {
                    Text("Hackatruck")
                        .foregroundStyle(.red)
                    Text("77 Universidades")
                        .foregroundStyle(.blue)
                    Text("5 Regioes do Brasil")
                        .foregroundStyle(.orange)
                }
            }
        }
    }
}

#Preview {
    Aula1AppDesafio2()
}
