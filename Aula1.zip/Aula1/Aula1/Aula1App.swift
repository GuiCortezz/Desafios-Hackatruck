//
//  Aula1App.swift
//  Aula1
//
//  Created by Turma02-10 on 02/07/25.
//

import SwiftUI

@main
struct Aula1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
