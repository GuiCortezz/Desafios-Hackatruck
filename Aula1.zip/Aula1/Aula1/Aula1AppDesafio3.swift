//
//  Aula1AppDesafio3.swift
//  Aula1
//
//  Created by Turma02-10 on 02/07/25.
//

import SwiftUI

struct Aula1AppDesafio3: View {
    @State var nome = ""
    @State var showingAlert = false
    var body: some View {
        ZStack {
            Image("WhatsApp Image 2020-03-02 at 14.41.09")
                .resizable()
                .scaledToFill()
                .frame(width: 390)
                .ignoresSafeArea()
                .opacity(0.3)
            
            Image("Caminhão")
                .resizable()
                .scaledToFit()
                .padding(50)
            VStack {
                Text("Bem vindo, \(nome)")
                    .font(.title)
                    .multilineTextAlignment(.center)
                
                TextField("Digite seu nome aqui:",text: $nome)
                    .padding(10)
                    .multilineTextAlignment(.center)
                    .font(.subheadline)
                Spacer()
                
                Button("Entrar") {
                    showingAlert = true
                }
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("ALERTA!"), message: Text("Voce irá iniciar o desafio agora"), dismissButton: .default(Text("Vamos Lá!")))
                }
            }
            }
        }
    }
    
    #Preview {
        Aula1AppDesafio3()
    }

