//
//  SwiftUIView.swift
//  Aula1
//
//  Created by Turma02-10 on 02/07/25.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        HStack {
            Rectangle()
                .fill(.red)
                .frame(width: 100, height: 100)
                .safeAreaPadding()
                Spacer()
            Rectangle()
                .fill(.blue)
                .frame(width: 100, height: 100)
                .safeAreaPadding()
        }
        VStack() {
            Spacer()
                
        }
        HStack {
            Rectangle()
                .fill(.green)
                .frame(width: 100, height: 100)
                .safeAreaPadding()
                Spacer()
            Rectangle()
                .fill(.yellow)
                .frame(width: 100, height: 100)
                .safeAreaPadding()
            
        }
    }
}

#Preview {
    SwiftUIView()
}
