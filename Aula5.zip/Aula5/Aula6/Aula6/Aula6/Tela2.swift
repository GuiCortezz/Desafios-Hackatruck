//
//  Tela2.swift
//  Aula6
//
//  Created by Turma02-10 on 14/07/25.
//

import SwiftUI

struct Tela2: View {
    @Binding var recebe: HaPo
    var body: some View {
        ZStack {
            Color.secondary
            .ignoresSafeArea()
            VStack {
                AsyncImage(url: URL(string: recebe.image!)) { image in
                    image.resizable()
                    
                } placeholder: {
                    ProgressView()
                }
                .frame(width: 100, height: 100)
                .clipShape(Circle())
                .padding()
                VStack(alignment: .leading) {
                    Text("Nome: \(recebe.name!)")
                    Text("**Nomes alternativos:**")
                    ForEach(recebe.alternate_names!, id: \.self) { a in
                        Text(a)
                    }
//                    Text(recebe.alternate_names!)
                    Text("Casa: \(recebe.house!)")
                    Text("Cor do olho: \(recebe.eyeColour!)")
                    Text("Patrono: \(recebe.patronus!)")
                }
                .bold()
                .font(.title2)
//                .multilineTextAlignment(.leading)
                .padding()
            }
        }
    }
}

#Preview {
    Tela2(recebe: .constant(HaPo(id: "", name: "aa", alternate_names: ["a", "e"], species: "", gender: "", house: "", dateOfBirth: "", yearOfBirth: 2020, wizard: true, ancestry: "", eyeColour: "", hairColour: "", wand: Wand(wood: "", core: "", lenght: 10.2), patronus: "", hogwartsStudent: true, hogwartsStaff: true, actor: "", alternate_actors: [""], alive: true, image: "")))
}
