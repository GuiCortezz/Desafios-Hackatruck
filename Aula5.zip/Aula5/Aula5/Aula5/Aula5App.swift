//
//  Aula5App.swift
//  Aula5
//
//  Created by Turma02-10 on 08/07/25.
//

import SwiftUI

@main
struct Aula5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
