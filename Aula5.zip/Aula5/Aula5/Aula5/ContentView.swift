//
//  ContentView.swift
//  Aula5
//
//  Created by Turma02-10 on 08/07/25.
//

import SwiftUI
import MapKit

struct Localizacao: Hashable {
    let nome: String
    let foto: String
    let descricao: String
    let longitude: Double
    let latitude: Double
}

//
//    init(_: pickerr = ["Muralha da China", "Cristo Redentor", "Machu Picchu", "Chichén Itza", "Coliseu", "Taj Mahal"], _: selecPick = Repeticao.pickerr) {
//        
//        self.pickerr = pickerr
//        self.selecPick = selecPick
//    }
    
struct ContentView: View {
    @State var sheetvieww = false
    @State var pickerr = Localizacao(nome: "Muralha da China", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4npNA3AXbwlyNKRDxnkAXpeTADMPoaYh__-l0z3UfCWWLT81C0pxUcwuzVeRKqCVF_wfjWXKrkhHNYsYcg9ecBIjbsVwSX2KLDJHl7g=w408-h265-k-no", descricao: "", longitude: 116.57039635767066, latitude: 40.432197611751796)
    
    @State var aux = Localizacao(nome: "Muralha da China", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4npNA3AXbwlyNKRDxnkAXpeTADMPoaYh__-l0z3UfCWWLT81C0pxUcwuzVeRKqCVF_wfjWXKrkhHNYsYcg9ecBIjbsVwSX2KLDJHl7g=w408-h265-k-no", descricao: "", longitude: 116.57039635767066, latitude: 40.432197611751796)
    
    @State var rep = [Localizacao(nome: "Muralha da China", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4npNA3AXbwlyNKRDxnkAXpeTADMPoaYh__-l0z3UfCWWLT81C0pxUcwuzVeRKqCVF_wfjWXKrkhHNYsYcg9ecBIjbsVwSX2KLDJHl7g=w408-h265-k-no", descricao: "Grande Muralha da China é uma série de fortificações feitas de pedra, tijolo, terra compactada, madeira e outros materiais, geralmente construída ao longo de uma linha leste-oeste através das fronteiras históricas do norte da China para proteger os Estados e impérios chineses contra as invasões dos vários grupos nômades das estepes da Eurásia, principalmente os mongóis.", longitude: 116.57039635767066, latitude: 40.432197611751796), Localizacao(nome: "Cristo Redentor", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4no3aLjwbBZ8aDR_OlaFCDqJWgEcrYOJYhJApvSbj-B1RgOHSoCq3M_h461bbzDyBhAgacGmtQwcXzeztf4nw0y-iTdneQwka8RD5w=w408-h272-k-no", descricao: "Cristo Redentor é uma estátua que retrata Jesus Cristo localizada no topo do morro do Corcovado, a 709 metros acima do nível do mar, dentro do Parque Nacional da Tijuca. Tem vista para parte considerável da cidade brasileira do Rio de Janeiro, sendo a frente da estátua voltada para a Baía de Guanabara e as costas para a Floresta da Tijuca. Feito de concreto armado e pedra-sabão,[1][2][3] tem trinta metros de altura (uma das maiores estátuas do mundo), sem contar os oito metros do pedestal, sendo a mais alta estátua do mundo no estilo Art Déco.[4][5] Seus braços se esticam por 28 metros de largura e a estrutura pesa 1145 toneladas.[6]", longitude: -43.210618923684706 , latitude: -22.950337790025046 ), Localizacao(nome: "Taj Mahal", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqtGLFjkquFIPAqblaev2OF3Tb-vQceTwi1C3-byQKLA1aar6AOoPO1xwC55DVyKYlnvhKPTyNKzi9C-__5GO_eTehHXgafoP9w=w408-h265-k-no", descricao: "O Taj Mahal (em hindi: ताज महल) é um mausoléu situado em Agra, na Índia, sendo o mais conhecido dos monumentos do país.[1] Encontra-se classificado pela UNESCO como Patrimônio da Humanidade. Foi anunciado em 2007 como uma das sete maravilhas do mundo moderno.", longitude:78.04224946409938, latitude:27.175402426541595 ), Localizacao(nome: "Machu Picchu", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqrgVDaHRCyfzeWb-g1FnDyKAek5sT4G-ktWLAQRWnhYrbehj6d9TAX_y6IVgc8558AFCQuJ2C3iF90s2gh9w14ZMmZxcML2C6wN0Y=w408-h306-k-no", descricao: "Machu Picchu, uma antiga cidade inca localizada no Peru, é conhecida por sua arquitetura impressionante, paisagens montanhosas e significado histórico e cultural. Erguida no topo de uma montanha a 2.430 metros de altitude, a cidadela é um exemplo notável da engenharia e urbanismo inca, com construções em pedra perfeitamente encaixadas, terraços agrícolas e templos religiosos. ", longitude: -72.54535866415411, latitude: -13.162948060480154)]
    
    @State var posicao = MapCameraPosition.region(MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 40.432197611751796, longitude: 116.57039635767066), span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30)))
    
    var body: some View {
        ZStack {
            VStack {
                Map(position: $posicao) {
                    
                    ForEach(rep, id: \.self) { posicao in
                        Annotation(posicao.nome, coordinate: CLLocationCoordinate2D(latitude: posicao.latitude, longitude: posicao.longitude)) {
                            
                            Image(systemName:  "mappin.and.ellipse.circle")
                                .imageScale(.large)
                                .onTapGesture {
                                    sheetvieww = true
                                    aux = posicao
                                    
                                }
                            
                        }
                        
                    }
                    
                }.sheet(isPresented: $sheetvieww) {
                    Tela2(recebe: $aux)
                    
                }
                .ignoresSafeArea()
            }
            VStack {
              //  Form {
                        Picker("",selection: $pickerr) {
                            ForEach(rep, id: \.self) { rep in
                                Text(rep.nome)
                                   
                            }
                        } .frame(width: 300, height: 50)
                          .background(.white)
                          .cornerRadius(10)
                          .tint(.black)
                
                        .onChange(of: pickerr) { _, e in posicao = MapCameraPosition.region(MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: e.latitude, longitude: e.longitude), span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30)))
                            
                        }
                        .pickerStyle(.menu)
                        .labelsHidden()
                  //  }
                Spacer()
                VStack {
                    Text("Maravilhas do Mundo Moderno")
                        .frame(width: 300, height: 75)
                        .background(Color.white)
                        .cornerRadius(10)
                        
                    }
                }
            }
        }
    }

#Preview {
    ContentView()
}
