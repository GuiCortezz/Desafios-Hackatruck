//
//  Tela2.swift
//  Aula5
//
//  Created by Turma02-10 on 08/07/25.
//

import SwiftUI

struct Tela2: View {
    @Binding var recebe : Localizacao
    var body: some View {
        ZStack {
            Color.yellow
            .ignoresSafeArea()
            VStack{
                AsyncImage(url: URL(string: recebe.foto)) {image in image
                    .image?.resizable()
                        .frame(width: 250, height: 250)
                        .cornerRadius(10)
                }
                Text(recebe.nome)
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                VStack {
                    Text(recebe.descricao)
                        .foregroundStyle(.white)
                        .frame(width: 300, height: 300)
                        .scaledToFit()
                        .padding()
                        .background(Color.brown)
                        .cornerRadius(10)
                }
            }
            
        }
    }
}

#Preview {
    Tela2(recebe: .constant(Localizacao(nome: "Muralha da China", foto: "https://lh3.googleusercontent.com/gps-cs-s/AC9h4npNA3AXbwlyNKRDxnkAXpeTADMPoaYh__-l0z3UfCWWLT81C0pxUcwuzVeRKqCVF_wfjWXKrkhHNYsYcg9ecBIjbsVwSX2KLDJHl7g=w408-h265-k-no", descricao: "aaaa", longitude: 116.57039635767066, latitude: 40.432197611751796)))
}
