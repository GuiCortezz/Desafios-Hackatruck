//
//  Aula_8.swift
//  Aula8
//
//  Created by Turma02-10 on 16/07/25.
//

import SwiftUI

struct Aula_8: View {
    
    @StateObject var viewModell = ViewModell()
    @State var sheetVieww = false
    @State var aux: Quitanda
    @State var aux2: Frutas
    @State var aux3: InfoNutri
    
    var body: some View {
        
        
        ZStack {
            Color.red
                .ignoresSafeArea()
            VStack {
                Rectangle()
                    .frame(width: 393, height: 200)
                    .foregroundStyle(Color.secondary)
                    .ignoresSafeArea()
                    .overlay(
                        Text("Clique no + para mais informacões!")
                            .font(.title)
                            .bold()
                            .multilineTextAlignment(.center)
                    )
                
                
                ScrollView {
                    ForEach(viewModell.quita, id: \.self){ e in
                        ForEach(e.frutasDisponiveis!, id: \.self){ a in
                            ForEach(a.nutrientes!, id: \.self){ f in
                                VStack {
                                    HStack {
                                        AsyncImage(url: URL(string: a.foto!)) { image in
                                            
                                            image.resizable()
                                            
                                        } placeholder: {
                                            ProgressView()
                                        }
                                        .frame(width: 100, height: 100)
                                        .clipShape(Circle())
                                        
                                        Text(a.nome!)
                                            .font(.title)
                                        Spacer()
                                        
                                        Image(systemName:  "plus.app.fill" )
                                            .imageScale(.large)
                                            .onTapGesture {
                                                sheetVieww = true
                                                aux = e
                                                aux2 = a
                                                aux3 = f
                                                
                                            }
                                    }
                                    .padding()
                                    Spacer()
                                    
                                }.sheet(isPresented: $sheetVieww) {
                                    Tela2(recebe: $aux, recebe2: $aux2, recebe3: $aux3)
                                }
                            }
                        }
                    }
                }
            }
        }
        .onAppear(){
            viewModell.fetch()
            
        }
    }
}
    
    #Preview {
        Aula_8(aux: Quitanda(nomeQuitanda: "aaa", enderecoQuitanda: "aaa", frutasDisponiveis: [Frutas(nome: "aa", nutrientes: [InfoNutri(Gorduras_Totais: " ", Colesterol: " ", Sódio: " ", Potássio: " ", Carboidratos: " ", Proteínas: "")])]), aux2: Frutas(nome: "aa", foto: " ", nutrientes: [InfoNutri(Gorduras_Totais: " ", Colesterol: " ", Sódio: " ", Potássio: " ", Carboidratos: " ", Proteínas: "")]), aux3: InfoNutri(Gorduras_Totais: " ", Colesterol: " ", Sódio: " ", Potássio: " ", Carboidratos: " ", Proteínas: ""))
    }
    

