//
//  Tela2.swift
//  Aula8
//
//  Created by Turma02-10 on 16/07/25.
//

import SwiftUI

struct Tela2: View {
    @Binding var recebe: Quitanda
    @Binding var recebe2: Frutas
    @Binding var recebe3: InfoNutri
    
    var body: some View {
        ZStack {
            Color.secondary
                .ignoresSafeArea()
            VStack {
                AsyncImage(url: URL(string: recebe2.foto!)) { image in
                    image.resizable()
                    
                } placeholder: {
                    ProgressView()
                }
                .frame(width: 100, height: 100)
                .clipShape(Circle())
                .padding()
                VStack(alignment: .leading) {
                    Text("Fruta: \(recebe2.nome!)")
                    Text("**Informação Nutricional :**")
                  //  ForEach(recebe3., id: \.self) { a in
                    Text("Carboidratos: \(recebe3.Carboidratos!)")
                        //   }
                        //                    Text(recebe.alternate_names!)
                        //    Text("Casa: \(recebe.house!)")
                        //    Text("Cor do olho: \(recebe.eyeColour!)")
                        // Text("Patrono: \(recebe.patronus!)")
                    }
                    .bold()
                    .font(.title2)
                    //                .multilineTextAlignment(.leading)
                    .padding()
                }
            }
        }
    }


#Preview {
    Tela2(recebe: .constant((Quitanda(nomeQuitanda: "", enderecoQuitanda: "", frutasDisponiveis: [Frutas(nome: "", foto: "", nutrientes: [InfoNutri(Gorduras_Totais: " ", Colesterol: " ", Sódio: " ", Potássio: " ", Carboidratos: " ", Proteínas: "")])] ))), recebe2: .constant(Frutas(nome: "", foto: "", nutrientes: [InfoNutri(Gorduras_Totais: " ", Colesterol: " ", Sódio: " ", Potássio: " ", Carboidratos: " ", Proteínas: "")])), recebe3: .constant(InfoNutri(Gorduras_Totais: " ", Colesterol: " ", Sódio: " ", Potássio: " ", Carboidratos: " ", Proteínas: "")))
}

