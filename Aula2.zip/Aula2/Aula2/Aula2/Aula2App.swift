//
//  Aula2App.swift
//  Aula2
//
//  Created by Turma02-10 on 03/07/25.
//

import SwiftUI

@main
struct Aula2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
