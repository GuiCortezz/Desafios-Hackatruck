//
//  ContentView.swift
//  Aula2
//
//  Created by Turma02-10 on 03/07/25.
//

import SwiftUI

struct ContentView: View {
    @State var distKm: Double = 0
    @State var tempH: Double = 0
    @State var calcula: Double = 0
    @State var botao = false
    @State var img = "interroga"
    @State var cor : Color = .gray
    
    var body: some View {
        ZStack {
            cor.ignoresSafeArea()
            VStack {
                Text("Digite a distância(km):")
                    .multilineTextAlignment(.center)
                TextField("0", value: $distKm, format: .number)
                    .multilineTextAlignment(.center)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding(3)
                    .textFieldStyle(.roundedBorder)
                    .cornerRadius(10)
                    .frame(width: 250)
                    
                Text("Digite o tempo(h):")
                    .multilineTextAlignment(.center)
                TextField("0", value: $tempH, format: .number)
                    .multilineTextAlignment(.center)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding(3)
                    .textFieldStyle(.roundedBorder)
                    .cornerRadius(10)
                    .frame(width: 250)
                
                Button("Calcular") {
                    botao = true
                  
                    calcula = distKm/tempH
                    
                    if botao {
                        switch calcula {
                        case 0..<10:
                           img = "tartaruga"
                            cor = .verdeClaro
                        case 10..<30:
                            img = "elefante"
                             cor = .azulClaro
                        case 30..<70:
                            img = "avestruz"
                             cor = .laranjaClaro
                        case 70..<90:
                            img = "leão"
                             cor = .amareloClaro
                        case 90...130:
                            img = "guepardo"
                             cor = .vermelhoClaro
                            
                        default:
                            img = "interroga"
                            cor = .gray
                            
                            
                        }
                    } else {
                       img = "ï"
                    }
                    
                }
                .padding()
                .foregroundColor(Color("laranjaClaro"))
                .background(Color.black)
                .clipShape(Rectangle())
                .cornerRadius(10)
                
                Text("\(String(format: "%.2f" ,calcula)) Km/h")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding(20)
                
                VStack {
                    Image(img)
                        .resizable()
                        .frame(width: 250, height: 200)
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        }
                .padding()
                    VStack {
                        HStack{
                            Text("TARTARUGA")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.leading)

                                Text("(0 - 9.9km/h)")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.trailing)
                            Spacer()
                                
                            Circle()
                                .fill(Color("verdeClaro"))
                                .frame(width: 20, height: 20)
                        }
                        HStack{
                            Text("ELEFANTE")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.leading)
                               
                                Text("(10 - 29,9km/h)")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.trailing)
                            Spacer()
                            
                            Circle()
                                .fill(Color("azulClaro"))
                                .frame(width: 20, height: 20)
                        
                        }
                        HStack{
                            Text("AVESTRUZ")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.leading)
                            
                               Text("(30 - 69.9km/h)")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.trailing)
                            Spacer()
                            Circle()
                                .fill(Color("laranjaClaro"))
                                .frame(width: 20, height: 20)
                        }
                        HStack{
                            Text("LEÃO")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.leading)
                            Text("(70 - 89.9km/h)")
                             .foregroundStyle(Color.white)
                             .multilineTextAlignment(.trailing)
                            Spacer()
                            Circle()
                                .fill(Color("amareloClaro"))
                                .frame(width: 20, height: 20)
                        }
                        HStack{
                            Text("GUEPARDO")
                                .foregroundStyle(Color.white)
                                .multilineTextAlignment(.leading)
                            
                            Text("(90 - 130km/h)")
                             .foregroundStyle(Color.white)
                             .multilineTextAlignment(.trailing)

                               Spacer()
                            Circle()
                                .fill(Color("vermelhoClaro"))
                                .frame(width: 20, height: 20)
                        }
                    }.padding()
                    .frame(width: 300, height: 200)
                    .background(Rectangle().fill(Color.black))
                    .cornerRadius(20)
                    
            }
        }
        
    }
}

#Preview {
    ContentView()
}
