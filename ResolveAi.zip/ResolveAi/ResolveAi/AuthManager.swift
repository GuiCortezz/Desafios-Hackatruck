//
//  AuthManager.swift
//  Project
//
//  Created by Turma02-10 on 28/07/25.
//

import Foundation

// Para o MVP, este objeto simula um sistema de login.
// Ele apenas guarda os IDs de um cliente e de um prestador para usarmos nos testes.
class AuthManager {
    static let shared = AuthManager()
    
    /// O ID do usuário que está "logado" como Cliente.
    let currentUserId_CLIENT: String = "313277b4aafef21c7252b7f1b8a8dd36"
    
    /// O ID do usuário que está "logado" como Prestador.
    let currentUserId_PROVIDER: String = "0ba738be0fb5f4e067b2dd5ec1ba5ea4"
    
    private init() {}
}
