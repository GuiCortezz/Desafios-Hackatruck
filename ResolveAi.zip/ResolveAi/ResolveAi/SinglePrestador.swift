import SwiftUI

struct SinglePrestador: View {
    
    @StateObject private var viewModel = ProviderViewModel()
    @State private var mostrarPopup = false

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            
            if viewModel.isLoading {
                ProgressView("Carregando Perfil...")
            } else if let errorMessage = viewModel.errorMessage {
                Text("Erro: \(errorMessage)")
                    .padding()
            } else if let user = viewModel.userProfile {
                VStack(spacing: 16) {
                    
                    AsyncImage(url: URL(string: user.photo ?? "")) { image in
                        image
                            .resizable()
                            .scaledToFill()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 150, height: 150)
                    .clipShape(Circle())
                        
                    Text(user.name)
                        .font(.title)
                        .bold()
                        
                    HStack {
                        Image(systemName: "mappin.circle")
                        Text("\(user.city), \(user.state)")
                            .foregroundColor(.gray)
                    }
                        
                    HStack {
                        VStack {
                            Image(systemName: "briefcase")
                            Text(user.occupation ?? "Não informado")
                        }
                        .frame(width: 120, height: 100)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                            
                        VStack {
                            Image(systemName: "dollarsign.circle")
                            Text(user.hourValueFormatted)
                                .font(.caption)
                                .bold()
                        }
                        .frame(width: 120, height: 100)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                    }
                        
                    Text(user.bio ?? "Sem biografia disponível.")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                        
                    Button("Contratar") {
                        mostrarPopup = true
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)
                    .foregroundStyle(.white)
                    .background(Color.blue)
                    .cornerRadius(55)
                    .padding(.top, 15)
                        
                    Spacer()
                }
                .padding(30)
                
                if mostrarPopup {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .onTapGesture {
                            mostrarPopup = false
                        }
                    
                    ContratoView(user: user)
                        .background(Color.white)
                        .cornerRadius(25)
                        .padding(30)
                        .shadow(radius: 10)
                        .frame(width: .infinity)
                }
            }
        }
        .onAppear {
            Task {
                await viewModel.fetchData()
            }
        }
    }
}

#Preview {
    SinglePrestador()

}
