//
//  sheetVieww.swift
//  Aula3desafio2
//
//  Created by Turma02-10 on 04/07/25.
//

import SwiftUI

struct sheetVieww: View {
    var body: some View {
        ZStack {
            Color.corback
                .ignoresSafeArea()
            VStack {
                Text("Sheet View")
                    .foregroundStyle(Color.white)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                Spacer()
                
                VStack {
                    Text("Nome: Guilherme")
                    Text("Sobrenome: Cortez")
                    
                }
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .frame(width: 300, height: 200)
                .background(Color.pink)
                .foregroundColor(.white)
                .cornerRadius(10)
                Spacer()
            }
        }
    }
}

#Preview {
    sheetVieww()
}
