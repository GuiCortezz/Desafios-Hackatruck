//
//  Aula3desafio2App.swift
//  Aula3desafio2
//
//  Created by Turma02-10 on 04/07/25.
//

import SwiftUI

@main
struct Aula3desafio2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
