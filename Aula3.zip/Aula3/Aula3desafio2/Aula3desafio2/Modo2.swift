//
//  Modo2.swift
//  Aula3desafio2
//
//  Created by Turma02-10 on 04/07/25.
//

import SwiftUI

struct Modo2: View {
    @State var nome = ""
    var body: some View {
        NavigationStack {
            ZStack {
                Color.corback
                    .ignoresSafeArea()
                VStack {
                    Text("Modo 2")
                        .foregroundStyle(Color.white)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .bold()
                    Spacer()
                    
                    VStack {
                        TextField("Nome",text: $nome)
                            .multilineTextAlignment(.center)
                            .padding()
                        Text("Bem vindo, \(nome)")
                        Spacer()
                        
                        NavigationLink(destination: Modo2_2(nome2: nome)) {
                            Text("Acessar Tela")
                                .multilineTextAlignment(.center)
                                .frame(width: 200, height: 50)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .shadow(radius: 10)
                                .cornerRadius(15)
                                .padding()
                                .font(.title2)
                                .bold()
                            
                        }
                        
                    }
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .frame(width: 300, height: 250)
                    .background(Color.pink)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    Modo2()
}
