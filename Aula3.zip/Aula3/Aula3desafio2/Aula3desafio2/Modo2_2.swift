//
//  Modo2_2.swift
//  Aula3desafio2
//
//  Created by Turma02-10 on 04/07/25.
//

import SwiftUI

struct Modo2_2: View {
    var nome2: String = ""
    var body: some View {
        ZStack {
            Color.corback
                .ignoresSafeArea()
            VStack {
                Text("Modo 2")
                    .foregroundStyle(Color.white)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                Spacer()
                
                VStack {
                    Text("Volte, ")
                    Text("\(nome2)")
                    
                }
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .frame(width: 200, height: 100)
                .background(Color.pink)
                .foregroundColor(.white)
                .cornerRadius(10)
                Spacer()
            }
        }
    }
}

#Preview {
    Modo2_2()
}
