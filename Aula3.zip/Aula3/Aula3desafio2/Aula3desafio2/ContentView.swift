//
//  ContentView.swift
//  Aula3desafio2
//
//  Created by Turma02-10 on 04/07/25.
//

import SwiftUI

struct ContentView: View {
   @State var botaoSheet = false
    var body: some View {
        NavigationStack {
            ZStack {
                Color.corback
                    .ignoresSafeArea()
                VStack {
                    Image("Hacka2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 150)
                    Spacer()
                    
                        NavigationLink(destination: Modo1()) {
                            Text("Modo 1")
                                .multilineTextAlignment(.center)
                                .frame(width: 300, height: 100)
                                .background(Color.pink)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .font(.title2)
                                .bold()
                        
                    }
                    NavigationLink(destination: Modo2()) {
                        Text("Modo 2")
                            .multilineTextAlignment(.center)
                            .frame(width: 300, height: 100)
                            .background(Color.pink)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .font(.title2)
                            .bold()
                    
                }
                    Button("Modo 3") {
                           botaoSheet = true
                    }
                    .multilineTextAlignment(.center)
                    .frame(width: 300, height: 100)
                    .background(Color.pink)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .font(.title2)
                    .bold()
                    
                    .sheet(isPresented: $botaoSheet) {
                        sheetVieww()
                    }
                    Spacer()
                    
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
