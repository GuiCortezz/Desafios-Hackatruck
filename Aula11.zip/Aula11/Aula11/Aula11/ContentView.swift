//
//  ContentView.swift
//  Aula11
//
//  Created by Turma02-10 on 21/07/25.
//

import SwiftUI

struct ContentView: View {
@StateObject var viewModell = ViewModell()
    @State var umidadeD : Int?
    var body: some View {
        ScrollView {
            VStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                
                if let ultimoItem = viewModell.umi.sorted(by: { $0.data < $1.data}).last {
                            Text("Último item: \(ultimoItem)")
                        } else {
                            Text("O array está vazio.")
                        }            }
            .onAppear(){
                viewModell.fetch()
                viewModell.startTimer()
                
                
//                for i in viewModell.umi {
//                    umidadeD = Int(i.umidade)
//                }
            }
            .onDisappear(){
                viewModell.stopTimer()
            }
            .padding()
        }
    }
}
    

#Preview {
    ContentView()
}
