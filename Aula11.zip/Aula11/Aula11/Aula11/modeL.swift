//
//  modeL.swift
//  Aula11
//
//  Created by Turma02-10 on 21/07/25.
//

import Foundation

struct Umidade: Decodable, Hashable {
    let umidade: String
    let data : Int
}
