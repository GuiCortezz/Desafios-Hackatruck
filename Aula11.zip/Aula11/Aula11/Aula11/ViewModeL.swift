//
//  ViewModeL.swift
//  Aula11
//
//  Created by Turma02-10 on 21/07/25.
//

import Foundation

class ViewModell: ObservableObject {
    private var timer: Timer?
    @Published var umi: [Umidade] = []
    
    func fetch() {
        
        guard let url = URL(string: "http://192.168.128.26:1880/leituraLixo") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) {
            [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Umidade].self, from: data)
                
                DispatchQueue.main.async {
                    
                    self?.umi = parsed
                }
            }
            catch {
                print(error)
            }
        }
        task.resume()
    }
    func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) {
            [weak self] _ in
            self?.fetch()
        }
    }
    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
}
