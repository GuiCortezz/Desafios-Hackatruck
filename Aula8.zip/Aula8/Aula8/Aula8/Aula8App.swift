//
//  Aula8App.swift
//  Aula8
//
//  Created by Turma02-10 on 16/07/25.
//

import SwiftUI

@main
struct Aula8App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
