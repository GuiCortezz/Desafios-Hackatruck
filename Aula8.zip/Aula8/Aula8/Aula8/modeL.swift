//
//  modeL.swift
//  Aula8
//
//  Created by Turma02-10 on 16/07/25.
//

import Foundation

struct Quitanda: Decodable, Hashable {
    let nomeQuitanda: String?
    let enderecoQuitanda: String?
    let frutasDisponiveis: [Frutas]?
}

struct Frutas: Decodable, Hashable {
    let nome: String?
    var foto: String?
    let nutrientes: [InfoNutri]?
}

struct InfoNutri: Decodable, Hashable {
    let Gorduras_Totais: String?
    let Colesterol: String?
    let Sódio: String?
    let Potássio: String?
    let Carboidratos: String?
    let Proteínas: String?
}
